# Ansible-PlayBooks
Ansible Playbooks for setting up the virtual machine

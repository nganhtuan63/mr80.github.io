# Base-Alpine-Nginx-PHP7-S6

This is the image for setting up Nginx, PHP-FPM 7 with common extensions, Composer based on the Alpine image. This image is used for running the PHP services of BasePlatform.

This image is also the base image for creating BasePlatform Development and Production Images.
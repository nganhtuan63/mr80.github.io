<?php

opcache_reset();

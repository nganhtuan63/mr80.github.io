<?php return array (
  0 => 
  array (
    'POST' => 
    array (
      '/system/apps/activate' => 'Base\\AppService\\Controller\\System\\ActivateAppAction',
      '/tenants/register' => 'Base\\TenantService\\Controller\\Site\\RegisterTenantAction',
    ),
  ),
  1 => 
  array (
  ),
);